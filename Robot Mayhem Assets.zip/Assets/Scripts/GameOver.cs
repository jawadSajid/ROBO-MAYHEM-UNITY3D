﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    int score = 0;
    public GUIElement gui;

    // Use this for initialization
    void Start()
    {
        //get our score from playerprefs
        score = PlayerPrefs.GetInt("Score");
        //multiply by 10 as we did on displayed score
        score = score * 10;
    }

    void OnGUI()
    {
        //set our text to our score
#pragma warning disable CS0618 // Type or member is obsolete
        gui.GetComponent<GUIText>().text = score.ToString();
#pragma warning restore CS0618 // Type or member is obsolete
                              //if retry button is pressed load scene 0 the game
        if (GUI.Button(new Rect(/*Screen.width / 2 - 50, Screen.height / 2 + 150*/400, 300, 75, 30), "Retry?"))
        {
            SceneManager.LoadScene(1);
        }
        //and quit button
        if (GUI.Button(new Rect(/*Screen.width / 2 - 50, Screen.height / 2 + 200*/400, 340, 75, 30), "Quit"))
        {
            Application.Quit();
            UnityEditor.EditorApplication.isPlaying = false;
        }
    }

}
